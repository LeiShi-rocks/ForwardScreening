
# install.packages('ggplot2')
# install.packages('reshape2')
# install.packages('dplyr')
# install.packages('gridExtra')
# install.packages('ggpubr')

source('code_04_figure2.R')

source('code_05_figureS1.R')

source('code_06_figureS2.R')

source('code_08_imce_estimation.R')

source('code_09_imce_estimation_bootstrap.R')

source('code_11_figureS3.R')

source('code_13_figure3.R')
